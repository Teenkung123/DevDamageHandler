package com.Teenkung.devDamageHandler.Indicator;

import com.Teenkung.devDamageHandler.Config.ScaleTarget;
import io.lumine.mythic.lib.damage.DamageType;
import org.bukkit.configuration.ConfigurationSection;

import java.util.*;

public class IndicatorSettings {
    public final boolean enabled;
    public final boolean split;

    public final String lineFormat;
    public final String immuneText;
    public final String numberFormat;

    public final String arrowUp;
    public final String arrowDown;

    // -------- flexible icon map --------
    private final Map<DamageType, IconPair> typeIcons;
    public final String elementalCritIcon;
    public final String defaultIconNormal;
    public final String defaultIconCrit;

    // multi-icon options
    public final boolean showBothWhenElement;
    public final boolean multiTypeIcons;
    public final int     maxTypeIcons;
    public final String  iconSeparator;
    public final List<IconOrder> iconOrder;

    // physics
    public final double radialVelocity;
    public final double gravity;
    public final double initialUpwardVelocity;
    public final double entityHeightPercent;
    public final double entityWidthPercent;
    public final double yOffset;
    public final double rOffset;
    public final boolean move;
    public final long lifespan;
    public final long tickPeriod;
    public final ScaleTarget scaleTarget;
    public final boolean stripPhysicalWhenElement;

    public IndicatorSettings(ConfigurationSection sec) {
        enabled        = sec.getBoolean("enabled", true);
        split          = sec.getBoolean("split-holograms", true);

        lineFormat     = sec.getString("line-format", "{arrow}{icon}<white>{value}</white>");
        immuneText     = sec.getString("immune-text", "{icon}<gray>IMMUNE");
        numberFormat   = sec.getString("number-format", "0.##");

        arrowUp        = sec.getString("arrow-up", "▲");
        arrowDown      = sec.getString("arrow-down", "▼");

        // -------- icon map parsing --------
        ConfigurationSection iconSec = sec.getConfigurationSection("icon");
        if (iconSec == null) iconSec = sec.createSection("icon");

        elementalCritIcon  = iconSec.getString("elemental-crit", "");
        defaultIconNormal  = iconSec.getString("default-normal", "");
        defaultIconCrit    = iconSec.getString("default-crit", "");

        showBothWhenElement = iconSec.getBoolean("show-both-when-element", false);
        multiTypeIcons      = iconSec.getBoolean("multi-type-icons", false);
        maxTypeIcons        = iconSec.getInt("max-type-icons", 0);
        iconSeparator       = iconSec.getString("icon-separator", "");
        stripPhysicalWhenElement = iconSec.getBoolean("strip-physical-when-element", true); // <--- NEW

        // order
        List<String> ord = iconSec.getStringList("order");
        if (ord == null || ord.isEmpty()) ord = List.of("ELEMENT", "TYPES");
        iconOrder = new ArrayList<>();
        for (String s : ord) {
            try { iconOrder.add(IconOrder.valueOf(s.toUpperCase(Locale.ROOT))); }
            catch (IllegalArgumentException ignored) {}
        }
        if (iconOrder.isEmpty()) iconOrder.add(IconOrder.ELEMENT);

        // build map of DamageType -> IconPair
        Map<DamageType, IconPair> tmp = new EnumMap<>(DamageType.class);
        ConfigurationSection typesSec = iconSec.getConfigurationSection("types");
        if (typesSec != null) {
            for (String key : typesSec.getKeys(false)) {
                try {
                    DamageType dt = DamageType.valueOf(key.toUpperCase(Locale.ROOT));
                    ConfigurationSection pairSec = typesSec.getConfigurationSection(key);
                    if (pairSec == null) continue;
                    String n = pairSec.getString("normal", "");
                    String c = pairSec.getString("crit", n);
                    tmp.put(dt, new IconPair(n, c));
                } catch (IllegalArgumentException ignored) { /* unknown enum */ }
            }
        }
        typeIcons = Collections.unmodifiableMap(tmp);

        // physics
        radialVelocity       = sec.getDouble("radial-velocity", 1.0);
        gravity              = sec.getDouble("gravity", 1.0);
        initialUpwardVelocity= sec.getDouble("initial-upward-velocity", 1.0);
        entityHeightPercent  = sec.getDouble("entity-height-percent", 0.75);
        entityWidthPercent   = sec.getDouble("entity-width-percent", 0.75);
        yOffset              = sec.getDouble("y-offset", 0.1);
        rOffset              = sec.getDouble("r-offset", 0.1);
        move                 = sec.getBoolean("move", true);
        lifespan             = sec.getLong("lifespan", 20L);
        tickPeriod           = sec.getLong("tick-period", 3L);

        scaleTarget          = ScaleTarget.fromString(sec.getString("scale-target"), ScaleTarget.BUKKIT);
    }

    /* ---------------------------------------------------------------- */
    /*  Icon helpers                                                    */
    /* ---------------------------------------------------------------- */

    /** returns FIRST matching icon out of the collection, old behavior */
    public String iconFor(Collection<DamageType> types, boolean crit) {
        List<String> list = iconListFor(types, crit);
        return list.isEmpty() ? (crit ? defaultIconCrit : defaultIconNormal) : list.get(0);
    }

    /** returns a list of icons, honoring multiTypeIcons & maxTypeIcons */
    public List<String> iconListFor(Collection<DamageType> types, boolean crit) {
        if (types == null || types.isEmpty()) return Collections.emptyList();
        List<String> out = new ArrayList<>();
        for (DamageType dt : types) {
            IconPair p = typeIcons.get(dt);
            if (p == null) continue;
            out.add(crit ? p.crit() : p.normal());
            if (!multiTypeIcons && !out.isEmpty()) break;
            if (maxTypeIcons > 0 && out.size() >= maxTypeIcons) break;
        }
        return out;
    }

    public String joinIcons(List<String> parts) {
        if (parts.isEmpty()) return "";
        if (iconSeparator == null || iconSeparator.isEmpty()) {
            return String.join("", parts);
        }
        return String.join(iconSeparator, parts);
    }

    /* data holders */
    private record IconPair(String normal, String crit) {}
    public enum IconOrder { ELEMENT, TYPES }
}
