package com.Teenkung.devDamageHandler.Indicator;

import com.Teenkung.devDamageHandler.Util.FontCodec;
import io.lumine.mythic.lib.MythicLib;
import io.lumine.mythic.lib.api.event.IndicatorDisplayEvent;
import io.lumine.mythic.lib.damage.DamageType;
import io.lumine.mythic.lib.element.Element;
import io.lumine.mythic.lib.hologram.Hologram;
import io.lumine.mythic.lib.listener.option.GameIndicators;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.util.Vector;

import java.text.DecimalFormat;
import java.util.*;
import java.util.stream.Collectors;

public class CustomIndicators extends GameIndicators {

    private static final Random RNG = new Random();

    private final IndicatorSettings settings;
    private final DecimalFormat formatter;
    private final FontCodec font;

    public CustomIndicators(ConfigurationSection original, FontCodec font) {
        // Give GameIndicators a fake section with the numeric/physics stuff it needs
        super(stubForGameIndicators(original));
        this.settings  = new IndicatorSettings(original);
        this.formatter = MythicLib.plugin.getMMOConfig().newDecimalFormat(settings.numberFormat);
        this.font      = font;
    }

    /* --------------------------------------------------------- */
    /*  PUBLIC ENTRY                                             */
    /* --------------------------------------------------------- */
    public void displayLines(Entity entity, List<IndicatorLine> lines) {
        if (!settings.enabled || lines.isEmpty()) return;

        if (settings.split) {
            for (IndicatorLine line : lines) displayOne(entity, line);
        } else {
            String joined = lines.stream().map(this::renderLine).collect(Collectors.joining(" "));
            displayOneRaw(entity, joined);
        }
    }

    /* --------------------------------------------------------- */

    private void displayOne(Entity entity, IndicatorLine line) {
        displayOneRaw(entity, renderLine(line));
    }

    private String renderLine(IndicatorLine l) {
        // 1) IMMUNE
        if (l.immune) {
            String immune = settings.immuneText.replace("{icon}", safe(l.iconOverride));
            return MythicLib.plugin.parseColors(immune);
        }

        // 2) Arrow (based on mobMul)
        String arrow = "";
        double mobMul = (l.mobMul == null ? 1.0 : l.mobMul);
        if (mobMul > 1.0001)       arrow = settings.arrowUp;
        else if (mobMul < 0.9999)  arrow = settings.arrowDown;

        // 3) Icon
        String icon = (l.iconOverride == null || l.iconOverride.isEmpty()) ? null : l.iconOverride;

        if (icon == null) {
            List<String> parts = new ArrayList<>();

            // Add element icon first or later depending on config.order
            for (IndicatorSettings.IconOrder ord : settings.iconOrder) {
                switch (ord) {
                    case ELEMENT -> {
                        if (l.element != null) {
                            parts.add(buildElementIcon(l.element, l.crit));
                        }
                    }
                    case TYPES -> {
                        if (settings.showBothWhenElement || l.element == null) {
                            if (l.types != null && !l.types.isEmpty()) {
                                Set<DamageType> filtered = l.types;
                                if (l.element != null && settings.stripPhysicalWhenElement) {
                                    // remove PHYSICAL if we detected any element damage
                                    filtered = EnumSet.copyOf(filtered);
                                    filtered.remove(DamageType.PHYSICAL);
                                }
                                if (!filtered.isEmpty()) {
                                    parts.addAll(settings.iconListFor(filtered, l.crit));
                                }
                            }
                        }
                    }

                }
            }

            icon = settings.joinIcons(parts);
        }

        icon = safe(icon);

        // 4) Number (format -> then encode if needed)
        String plain = formatter.format(l.value);
        String number = (font != null && font.isEnabled()) ? font.encodeString(plain, l.crit) : plain;

        // 5) Compose line
        String mini = settings.lineFormat
                .replace("{arrow}", arrow)
                .replace("{icon}", icon)
                .replace("{value}", number);

        return MythicLib.plugin.parseColors(mini);
    }

    private String buildElementIcon(Element element, boolean crit) {
        // MythicLib “color” is usually a legacy/§ color; loreIcon is the actual glyph
        String color = safe(element.getColor());
        String glyph = safe(element.getLoreIcon());

        // Optional: prepend your crit icon. If you don’t want that, just remove this line.
        String critAddon = crit ? safe(settings.elementalCritIcon) : "";

        // DO NOT font-encode this glyph—leave it raw so MythicLib’s RP font shows it.
        return critAddon + color + glyph;
    }


    private String safe(String s) { return s == null ? "" : s; }


    /** Convert MiniMessage → legacy '&' → MythicLib color parser (if you still need it). */
    @SuppressWarnings("unused")
    private String toLegacy(String mini) {
        String legacy = LegacyComponentSerializer.legacyAmpersand()
                .serialize(MiniMessage.miniMessage().deserialize(mini));
        return MythicLib.plugin.parseColors(legacy);
    }

    private void displayOneRaw(Entity entity, String legacyMsg) {
        IndicatorDisplayEvent called = new IndicatorDisplayEvent(entity, legacyMsg,
                IndicatorDisplayEvent.IndicatorType.DAMAGE);
        Bukkit.getPluginManager().callEvent(called);
        if (called.isCancelled()) return;

        // Positioning
        double a = RNG.nextDouble() * Math.PI * 2;
        double width = (entity.getBoundingBox().getWidthX() + entity.getBoundingBox().getWidthZ()) / 2.0;
        double r = this.rOffset + width * this.entityWidthPercent;
        double h = this.yOffset + entity.getHeight() * this.entityHeightPercent;
        Location loc = entity.getLocation().add(Math.cos(a) * r, h, Math.sin(a) * r);

        Hologram holo = Hologram.create(loc, Collections.singletonList(legacyMsg));
        if (!settings.move) {
            Bukkit.getScheduler().runTaskLater(MythicLib.plugin, holo::despawn, settings.lifespan);
        } else {
            holo.flyOut(this, randomDir(entity));
        }
    }

    private Vector randomDir(Entity e) {
        double ang = RNG.nextDouble() * Math.PI * 2;
        return new Vector(Math.cos(ang), 0, Math.sin(ang));
    }

    /**
     * Build a minimal section containing only what GameIndicators cares about
     * so we can keep all the fancy stuff in our own settings.
     */
    private static ConfigurationSection stubForGameIndicators(ConfigurationSection src) {
        org.bukkit.configuration.MemoryConfiguration mc = new org.bukkit.configuration.MemoryConfiguration();
        mc.set("decimal-format", src.getString("decimal-format", "0.##"));
        mc.set("format",          src.getString("format", "{value}"));

        mc.set("radial-velocity",         src.getDouble("radial-velocity", 1.0));
        mc.set("gravity",                 src.getDouble("gravity", 1.0));
        mc.set("initial-upward-velocity", src.getDouble("initial-upward-velocity", 1.0));
        mc.set("entity-height-percent",   src.getDouble("entity-height-percent", 0.75));
        mc.set("entity-width-percent",    src.getDouble("entity-width-percent", 0.75));
        mc.set("y-offset",                src.getDouble("y-offset", 0.1));
        mc.set("r-offset",                src.getDouble("r-offset", 0.1));
        mc.set("move",                    src.getBoolean("move", true));
        mc.set("lifespan",                src.getLong("lifespan", 20L));
        mc.set("tick-period",             src.getLong("tick-period", 3L));
        return mc;
    }
}
