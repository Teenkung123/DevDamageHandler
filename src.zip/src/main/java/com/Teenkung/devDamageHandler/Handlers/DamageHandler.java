package com.Teenkung.devDamageHandler.Handlers;

import com.Teenkung.devDamageHandler.Config.CombineMode;
import com.Teenkung.devDamageHandler.Config.ElementResolver;
import com.Teenkung.devDamageHandler.Config.MultiplierUtil;
import com.Teenkung.devDamageHandler.Config.TypeResolver;
import com.Teenkung.devDamageHandler.DevDamageHandler;
import com.Teenkung.devDamageHandler.Indicator.IndicatorLine;
import com.Teenkung.devDamageHandler.Indicator.IndicatorSettings;
import com.Teenkung.devDamageHandler.Util.Msg;
import com.Teenkung.devDamageHandler.Util.PacketAccess;
import io.lumine.mythic.bukkit.MythicBukkit;
import io.lumine.mythic.lib.api.event.IndicatorDisplayEvent;
import io.lumine.mythic.lib.api.event.PlayerAttackEvent;
import io.lumine.mythic.lib.damage.DamageMetadata;
import io.lumine.mythic.lib.damage.DamagePacket;
import io.lumine.mythic.lib.damage.DamageType;
import io.lumine.mythic.lib.element.Element;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

import java.util.*;
import java.util.stream.Collectors;

public class DamageHandler implements Listener {

    private final DevDamageHandler plugin;

    public DamageHandler(DevDamageHandler plugin) {
        this.plugin = plugin;
    }

    /* ---------------------------------------------------- */
    /*  FILTER MYTHICLIB HOLOGRAMS: cancel "0"              */
    /* ---------------------------------------------------- */
    @EventHandler
    public void onIndicatorDisplay(IndicatorDisplayEvent event) {
        String number = plugin.getFontCodec().decodeNumbers(event.getMessage());
        if ("0".equals(number) || ".0".equals(number)) event.setCancelled(true);
    }

    /* ---------------------------------------------------- */
    /*  MAIN DAMAGE PIPELINE                                */
    /* ---------------------------------------------------- */
    // -------------- FIRST STAGE: modify damage --------------
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamageModify(PlayerAttackEvent event) {
        String mobId = mythicId(event.getEntity());
        if (mobId == null) return;

        DamageMetadata dmg = event.getDamage();
        Map<Element, Double> elemRaw = dmg.mapElementalDamage();

        boolean debug = plugin.getPlayerDebugMode(event.getAttacker().getPlayer());
        DebugPrinter dbg = debug ? new DebugPrinter(mobId, dmg, elemRaw) : null;

        // 0) flat tweaks
        applyFlatTweaks(dmg, elemRaw);

        // 1) load resolvers/mods
        TypeResolver tRes      = plugin.getTypeResolver(mobId);
        ElementResolver eRes   = plugin.getElementResolver(mobId);
        var typeMods           = plugin.getConfigLoader().getDamageTypeModifiers(mobId);
        var elemMods           = plugin.getConfigLoader().getElementalModifiers(mobId);

        // 2) type stage
        applyTypeStage(dmg, tRes, typeMods, dbg);

        // 3) element stage
        ElementStageResult elemRes = applyElementStage(dmg, elemRaw, elemMods, eRes, event, dbg);

        // 4) optional big debug dump
        if (debug) dbg.printFinal(dmg, event.getAttacker().getPlayer());

        // 5) store context for later (indicator stage)
        HitContext ctx = new HitContext(
                new HashMap<>(elemRaw),
                elemRes.mobMul(),
                elemRes.critMul(),
                dmg.isWeaponCriticalStrike(),
                dmg.isSkillCriticalStrike(),
                mobId
        );
        plugin.rememberHit(dmg, ctx);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamageShow(PlayerAttackEvent event) {
        DamageMetadata dmg = event.getDamage();
        HitContext ctx = plugin.consumeHit(dmg);
        if (ctx == null) return; // not our hit / not a mythic mob

        pushIndicatorsFinal(event, dmg, ctx);
    }


    /* ---------------------------------------------------- */
    /*  STAGES                                              */
    /* ---------------------------------------------------- */

    private void applyFlatTweaks(DamageMetadata dmg, Map<Element, Double> elem) {
        double totalElemental = elem.values().stream().mapToDouble(Double::doubleValue).sum();
        if (totalElemental <= 0) return;

        if (dmg.getDamage(DamageType.PHYSICAL) > 0) {
            dmg.additiveModifier(-2.115, DamageType.PHYSICAL);
            if (dmg.getDamage(DamageType.PHYSICAL) < 0.1) dmg.multiplicativeModifier(0, DamageType.PHYSICAL);
        }
        if (dmg.getDamage(DamageType.MAGIC) > 0) {
            double amt = dmg.isWeaponCriticalStrike() ? -3.375 : -1.5;
            dmg.additiveModifier(amt, DamageType.MAGIC);
            if (dmg.getDamage(DamageType.MAGIC) < 0.1) dmg.multiplicativeModifier(0, DamageType.MAGIC);
        }
    }

    private TypeStageResult applyTypeStage(DamageMetadata dmg,
                                           TypeResolver resolver,
                                           Map<DamageType, Double> mods,
                                           DebugPrinter dbg) {
        if (mods == null || mods.isEmpty()) return new TypeStageResult(Collections.emptyMap()); // FIX

        Map<DamageType, List<Double>> perTypeMul = new EnumMap<>(DamageType.class);
        Map<DamagePacket, Double> orphanMul = new IdentityHashMap<>();

        Map<DamagePacket, DebugPrinter.TypeStep> debugMap = dbg == null ? null : new IdentityHashMap<>();

        Set<DamageType> fallback = dmg.collectTypes().isEmpty()
                ? EnumSet.noneOf(DamageType.class)
                : EnumSet.copyOf(dmg.collectTypes());

        for (DamagePacket pkt : dmg.getPackets()) {
            DamageType[] arr = pkt.getTypes();
            Set<DamageType> types = (arr.length == 0) ? fallback : EnumSet.copyOf(Arrays.asList(arr));
            if (types.isEmpty()) continue;

            DamageType primary = resolver.pickPrimary(types);
            LinkedHashMap<DamageType, Double> used = new LinkedHashMap<>();
            if (primary != null) addIfPresent(mods, used, primary);
            if (resolver.isFlagsAffectPrimary()) {
                for (DamageType dt : types) if (dt != primary && resolver.isFlag(dt)) addIfPresent(mods, used, dt);
            }

            double mul = used.isEmpty() ? 1.0 : MultiplierUtil.combine(used.values(), resolver.getCombineMode());

            if (mul != 1.0) {
                if (arr.length == 0) orphanMul.put(pkt, mul);
                else for (DamageType dt : types) if (!resolver.isFlag(dt)) perTypeMul.computeIfAbsent(dt, k -> new ArrayList<>()).add(mul);
            }

            if (dbg != null) debugMap.put(pkt, new DebugPrinter.TypeStep(primary, used, mul, arr.length == 0));
        }

        // apply final
        for (Map.Entry<DamageType, List<Double>> e : perTypeMul.entrySet()) {
            double f = MultiplierUtil.combine(e.getValue(), resolver.getCombineMode());
            if (f != 1.0) {
                dmg.multiplicativeModifier(f, e.getKey());
                if (dbg != null) dbg.globalTypeMul(e.getKey(), f);
            }
        }
        for (Map.Entry<DamagePacket, Double> e : orphanMul.entrySet()) {
            PacketAccess.multiplyValue(e.getKey(), e.getValue());
            if (dbg != null) dbg.orphanMul(e.getValue());
        }



        return new TypeStageResult(debugMap);
    }

    private ElementStageResult applyElementStage(DamageMetadata dmg,
                                                 Map<Element, Double> raw,
                                                 Map<Element, Double> mods,
                                                 ElementResolver resolver,
                                                 PlayerAttackEvent event,
                                                 DebugPrinter dbg) {
        Map<Element, Double> critMul = new HashMap<>();
        Map<Element, Double> mobMul  = new HashMap<>();

        if (mods == null || mods.isEmpty()) {
            raw.keySet().forEach(e -> { critMul.put(e, 1.0); mobMul.put(e, 1.0); });
            return new ElementStageResult(critMul, mobMul);
        }

        for (Element el : raw.keySet()) {
            // crit
            double cMul = 1.0;
            if (dmg.isWeaponCriticalStrike() && resolver.hasCrit()) {
                cMul = resolver.critMultiplier(event.getAttacker());
                if (cMul != 1.0) {
                    dmg.multiplicativeModifier(cMul, el);
                    dmg.registerElementalCriticalStrike(el);
                }
            }
            critMul.put(el, cMul);

            Double mMul = mods.get(el);
            if (mMul == null) mMul = 1.0;
            if (mMul == 0) {
                dmg.multiplicativeModifier(0, el);
            } else if (mMul != 1.0) {
                dmg.multiplicativeModifier(mMul, el);
            }
            mobMul.put(el, mMul);
        }

        if (dbg != null) dbg.elementStage(raw, critMul, mobMul);

        return new ElementStageResult(critMul, mobMul);
    }

    private void pushIndicatorsFinal(PlayerAttackEvent event,
                                     DamageMetadata dmg,
                                     HitContext ctx) {

        IndicatorSettings set = plugin.getIndicatorSettings();
        if (set == null || !set.enabled) return;

        final boolean debug = plugin.getPlayerDebugMode(event.getAttacker().getPlayer());
        StringBuilder indDbg = debug ? new StringBuilder() : null;

        List<IndicatorLine> lines = new ArrayList<>();

        /* ---------- 1) ELEMENT LINES ---------- */
        double elementFinalTotal = 0.0; // <-- FINAL, not base
        for (Element el : ctx.elemBase().keySet()) {
            double base = ctx.elemBase().get(el);                 // raw base from MythicLib
            double mobM = ctx.elemMobMul().getOrDefault(el, 1.0); // mob resist/vuln
            double crtM = ctx.elemCritMul().getOrDefault(el, 1.0); // elemental crit mul (if any)

            boolean immune  = mobM == 0.0;
            boolean crit    = crtM != 1.0;
            double finalVal = immune ? 0.0 : base * mobM * crtM;

            elementFinalTotal += finalVal;
            lines.add(new IndicatorLine(finalVal, immune, crit, el, dmg.collectTypes(), mobM, null));
        }

        /* ---------- 2) NON-ELEMENT LINE ---------- */
        boolean hasElements = !ctx.elemBase().isEmpty();
        DamagePacket carrier = guessCarrierPacket(dmg, hasElements);

        // Sum packets AFTER all modifiers (ours + others)
        double packetsSum = dmg.getPackets().stream()
                .mapToDouble(DamagePacket::getFinalValue)
                .sum();

        double carrierVal = (carrier == null) ? 0.0 : carrier.getFinalValue();

        // Use FINAL elemental sum to avoid the “leftover” you saw (0.5)
        double nonElem = packetsSum - carrierVal - elementFinalTotal;
        if (nonElem < 0) nonElem = 0; // rounding guard

        if (nonElem > 0.0001) {
            boolean crit = ctx.wasWeaponCrit() || ctx.wasSkillCrit();
            Set<DamageType> types = dmg.collectTypes();
            if (!ctx.elemBase().isEmpty() && plugin.getIndicatorSettings().stripPhysicalWhenElement) {
                // remove PHYSICAL
                types = EnumSet.copyOf(types);
                types.remove(DamageType.PHYSICAL);
            }
            lines.add(new IndicatorLine(nonElem, false, crit, null, types, 1.0, null));
        }


        /* ---------- 3) SCALING (configurable) ---------- */
        double sumDisplay = lines.stream()
                .filter(l -> !l.immune && l.value > 0.0001)
                .mapToDouble(l -> l.value)
                .sum();

        double targetTotal = switch (set.scaleTarget) {
            case META    -> dmg.getDamage();                        // MythicLib internal sum after modifiers
            case PACKETS -> packetsSum;                             // Σ packet.final
            case NONE    -> sumDisplay;                             // no scaling
            case BUKKIT  -> event.toBukkit().getFinalDamage();      // vanilla/bukkit final
        };

        double scale = 1.0;
        if (sumDisplay > 0.0001 && Math.abs(targetTotal - sumDisplay) > 0.0001) {
            scale = targetTotal / sumDisplay;
            List<IndicatorLine> scaled = new ArrayList<>(lines.size());
            for (IndicatorLine l : lines) {
                if (!l.immune && l.value > 0.0001) {
                    scaled.add(new IndicatorLine(l.value * scale, false, l.crit, l.element, l.types, l.mobMul, l.iconOverride));
                } else {
                    scaled.add(l);
                }
            }
            lines = scaled;
        }

        /* ---------- 4) DEBUG ---------- */
        if (debug && indDbg != null) {
            indDbg.append("<yellow>Indicator Stage Debug:</yellow>\n")
                    .append("<gray>scale-target:</gray> <white>").append(set.scaleTarget).append("</white>\n")
                    .append("<gray>metaDamageSum (dmg.getDamage()):</gray> <white>").append(fmt(dmg.getDamage())).append("</white>\n")
                    .append("<gray>packetsSum (Σ packet.final):</gray> <white>").append(fmt(packetsSum)).append("</white>\n")
                    .append("<gray>Bukkit final:</gray> <white>").append(fmt(event.toBukkit().getFinalDamage())).append("</white>\n")
                    .append("<gray>carrierVal:</gray> <white>").append(fmt(carrierVal)).append("</white>\n")
                    .append("<gray>elementFinalTotal (we show):</gray> <white>").append(fmt(elementFinalTotal)).append("</white>\n")
                    .append("<gray>nonElem (pre-scale):</gray> <white>").append(fmt(nonElem)).append("</white>\n")
                    .append("<gray>sumDisplay (pre-scale):</gray> <white>").append(fmt(sumDisplay)).append("</white>\n")
                    .append("<gray>targetTotal:</gray> <white>").append(fmt(targetTotal)).append("</white>\n")
                    .append("<gray>scale:</gray> <white>").append(fmt(scale)).append("</white>\n")
                    .append("<gray>Lines:</gray>\n");

            int i = 1;
            for (IndicatorLine l : lines) {
                indDbg.append("  #").append(i++).append(" val=").append(fmt(l.value))
                        .append(" immune=").append(l.immune)
                        .append(" crit=").append(l.crit)
                        .append(" elem=").append(l.element == null ? "null" : l.element.getId())
                        .append(" types=").append(l.types == null ? "[]" : l.types)
                        .append("\n");
            }
            Msg.send(event.getAttacker().getPlayer(), indDbg.toString());
        }

        /* ---------- 5) SHOW ---------- */
        plugin.getIndicators().displayLines(event.getEntity(), lines);
    }

    /** If there are elements, MythicLib always puts the tiny typed packet first. */
    private DamagePacket guessCarrierPacket(DamageMetadata dmg, boolean hasElements) {
        if (!hasElements) return null;
        List<DamagePacket> list = dmg.getPackets();
        if (list.isEmpty()) return null;
        DamagePacket first = list.get(0);
        return (first.getTypes().length > 0) ? first : null;
    }


    /* ---------------------------------------------------- */
    /*  HELPERS & RECORDS                                    */
    /* ---------------------------------------------------- */

    private String mythicId(LivingEntity e) {
        if (!MythicBukkit.inst().getMobManager().isMythicMob(e)) return null;
        return MythicBukkit.inst().getMobManager().getMythicMobInstance(e).getMobType();
    }

    private void addIfPresent(Map<DamageType, Double> src, Map<DamageType, Double> dst, DamageType key) {
        Double v = src.get(key);
        if (v != null) dst.put(key, v);
    }

    /* type stage result */
    private record TypeStageResult(Map<DamagePacket, DebugPrinter.TypeStep> debugMap) {}

    /* element stage result */
    private record ElementStageResult(Map<Element, Double> critMul,
                                      Map<Element, Double> mobMul) {}

    /* Debug printer */
    private static class DebugPrinter {
        private final StringBuilder sb = new StringBuilder();
        private final String mobId;
        private final DamageMetadata dmg;
        private final Map<Element, Double> elemRaw;

        DebugPrinter(String mobId, DamageMetadata dmg, Map<Element, Double> elemRaw) {
            this.mobId = mobId;
            this.dmg = dmg;
            this.elemRaw = elemRaw;
            header();
        }

        void indicatorStage(double metaDamageSum,
                            double packetsSum,
                            double carrierVal,
                            double elemBaseTotal,
                            double nonElemPreScale,
                            double sumDisplayPreScale,
                            double bukkitFinal,
                            double scale,
                            List<IndicatorLine> lines,
                            TypeStageResult typeRes) {  // optional use

            sb.append("<yellow>Indicator Stage Debug:</yellow>\n")
                    .append("<gray>metaDamageSum:</gray> <white>").append(fmt(metaDamageSum)).append("</white>\n")
                    .append("<gray>packetsSum:</gray> <white>").append(fmt(packetsSum)).append("</white>\n")
                    .append("<gray>carrierVal:</gray> <white>").append(fmt(carrierVal)).append("</white>\n")
                    .append("<gray>elementBaseTotal:</gray> <white>").append(fmt(elemBaseTotal)).append("</white>\n")
                    .append("<gray>nonElem (pre-scale):</gray> <white>").append(fmt(nonElemPreScale)).append("</white>\n")
                    .append("<gray>sumDisplay (pre-scale):</gray> <white>").append(fmt(sumDisplayPreScale)).append("</white>\n")
                    .append("<gray>Bukkit final:</gray> <white>").append(fmt(bukkitFinal)).append("</white>\n")
                    .append("<gray>scale:</gray> <white>").append(fmt(scale)).append("</white>\n");

            sb.append("<gray>Lines after scale:</gray>\n");
            int idx = 1;
            for (IndicatorLine l : lines) {
                sb.append("  #").append(idx++).append(" val=").append(fmt(l.value))
                        .append(" immune=").append(l.immune)
                        .append(" crit=").append(l.crit)
                        .append(" elem=").append(l.element == null ? "null" : l.element.getId())
                        .append(" types=").append(l.types == null ? "[]" : l.types)
                        .append("\n");
            }

            // OPTIONAL: dump packet type steps (from TypeStageResult)
            if (typeRes != null && typeRes.debugMap() != null && !typeRes.debugMap().isEmpty()) {
                sb.append("<gray>TypeSteps (from TypeStageResult):</gray>\n");
                int k = 1;
                for (Map.Entry<DamagePacket, TypeStep> e : typeRes.debugMap().entrySet()) {
                    TypeStep t = e.getValue();
                    sb.append("  pkt#").append(k++).append(" mul=").append(fmt(t.result()))
                            .append(" primary=").append(t.primary())
                            .append(" orphan=").append(t.orphan())
                            .append(" applied=").append(t.applied()).append("\n");
                }
            }
        }

        private void header() {
            sb.append("<gray>========= <gold>Damage Debug <gray>=========\n")
                    .append("<yellow>Target:</yellow> <white>").append(mobId).append("</white>\n")
                    .append("<yellow>Raw Packets:</yellow>\n");
            int i = 1;
            for (DamagePacket p : dmg.getPackets()) {
                sb.append("  <gray>#").append(i++).append("</gray> <white>")
                        .append(fmt(p.getFinalValue()))
                        .append("</white> <gray>types=</gray><white>")
                        .append(Arrays.toString(p.getTypes()))
                        .append("</white>\n");
            }
            if (!elemRaw.isEmpty()) {
                sb.append("<yellow>Elements Raw:</yellow>\n");
                elemRaw.forEach((el, val) ->
                        sb.append("  <white>").append(el.getId()).append("</white>: <white>").append(fmt(val)).append("</white>\n"));
            } else {
                sb.append("<yellow>Elements Raw:</yellow> <dark_gray>(none)</dark_gray>\n");
            }
        }

        void globalTypeMul(DamageType dt, double mul) {
            sb.append("<gray>Applied Global Type Mul: </gray><white>").append(dt)
                    .append("</white><gray> = </gray><white>").append(fmt(mul)).append("</white>\n");
        }

        void orphanMul(double mul) {
            sb.append("<gray>Applied Orphan Packet Mul: </gray><white>").append(fmt(mul)).append("</white>\n");
        }

        record TypeStep(DamageType primary, LinkedHashMap<DamageType, Double> applied, double result, boolean orphan) {}

        void elementStage(Map<Element, Double> base, Map<Element, Double> crit, Map<Element, Double> mob) {
            if (base.isEmpty()) return;
            sb.append("<yellow>Element Calculations:</yellow>\n");
            for (Element el : base.keySet()) {
                double c = crit.getOrDefault(el, 1.0);
                double m = mob.getOrDefault(el, 1.0);
                double f = c * m;
                sb.append("  <white>").append(el.getId()).append("</white>: ")
                        .append("<gray>base=</gray><white>").append(fmt(base.get(el))).append("</white> ")
                        .append("<gray>mobMul=</gray><white>").append(fmt(m)).append("</white> ")
                        .append("<gray>critMul=</gray><white>").append(fmt(c)).append("</white> ")
                        .append("<gray>finalMul=</gray><white>").append(fmt(f)).append("</white>\n");
            }
        }

        void printFinal(DamageMetadata dmg, Player player) {
            sb.append("<yellow>Packet Type Calculations:</yellow>\n");
            int i = 1;
            for (DamagePacket pkt : dmg.getPackets()) {
                sb.append("  <gray>#").append(i++).append("</gray> ")
                        .append("<white>").append(fmt(pkt.getFinalValue())).append("</white>")
                        .append(" <gray>types=</gray><white>")
                        .append(Arrays.toString(pkt.getTypes())).append("</white>\n");
            }

            sb.append("<yellow>Final Packets:</yellow>\n");
            double sum = 0;
            int j = 1;
            for (DamagePacket p : dmg.getPackets()) {
                sb.append("  <gray>#").append(j++).append("</gray> <white>")
                        .append(fmt(p.getFinalValue()))
                        .append("</white> <gray>types=</gray><white>")
                        .append(Arrays.toString(p.getTypes()))
                        .append("</white>\n");
                sum += p.getFinalValue();
            }
            sb.append("<gray>Total Final Damage:</gray> <white>").append(fmt(sum)).append("</white>\n");
            sb.append("<gray>====================================</gray>");

            Msg.send(player, sb.toString());
        }
    }

    private static String fmt(double d) {
        if (Math.abs(d - Math.rint(d)) < 1e-9) return String.valueOf((long)Math.rint(d));
        return String.format(Locale.US, "%.3f", d);
    }



    private static String buildFormulaString(Collection<Double> vals, CombineMode mode) {
        if (vals.isEmpty()) return "1.0";
        List<String> parts = vals.stream().map(DamageHandler::fmt).toList();
        return switch (mode) {
            case PRODUCT -> String.join(" * ", parts);
            case MIN     -> "min(" + String.join(", ", parts) + ")";
            case MAX     -> "max(" + String.join(", ", parts) + ")";
            case AVERAGE -> "avg(" + String.join(", ", parts) + ")";
            case SOFT_ADD, RESIST_ADD -> {
                String inv = parts.stream().map(p -> "(1-" + p + ")").collect(Collectors.joining(" * "));
                yield "1 - " + inv;
            }
            default -> String.join(" ? ", parts);
        };
    }

    // New file or inner class
    public record HitContext(
            Map<Element, Double> elemBase,          // raw base per element
            Map<Element, Double> elemMobMul,        // mob multiplier per element
            Map<Element, Double> elemCritMul,       // crit mul per element
            boolean wasWeaponCrit,                  // for non-element crit icon
            boolean wasSkillCrit,
            String mobId
    ) {}

}
