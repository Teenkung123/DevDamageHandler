package com.Teenkung.devDamageHandler.Config;

import com.Teenkung.devDamageHandler.Util.IndicatorUtil;
import io.lumine.mythic.lib.element.Element;
import io.lumine.mythic.lib.player.PlayerMetadata;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.teenkung123.damageindicator.api.DamageIndicatorAPI;

public class ElementResolver {

    private final CombineMode combineMode;
    private final boolean     showImmune;
    private final String      immuneFormat;
    private final String      critStat;

    public ElementResolver(CombineMode combineMode, boolean showImmune, String immuneFormat, String critStat) {
        this.combineMode = combineMode;
        this.showImmune = showImmune;
        this.immuneFormat = immuneFormat;
        this.critStat = critStat;
    }

    public boolean hasCrit() {
        return critStat != null;
    }

    public double critMultiplier(PlayerMetadata attacker) {
        if (critStat == null) return 1.0;
        return attacker.getStat(critStat) / 100.0;
    }

    public void indicateImmune(LivingEntity target, Element el) {
        if (!showImmune) return;
        IndicatorUtil.show(target, el.getLoreIcon() + immuneFormat);
//        DamageIndicatorAPI.getInstance().displayDamageIndicator(
//                target, el.getLoreIcon() + immuneFormat
//        );
    }

    public CombineMode getCombineMode() {
        return combineMode;
    }

    public boolean isShowImmune() {
        return showImmune;
    }

    public String getImmuneFormat() {
        return immuneFormat;
    }

    public String getCritStat() {
        return critStat;
    }
}
